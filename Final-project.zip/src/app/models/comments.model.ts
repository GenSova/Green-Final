export class Comment {
  name: string;
  message: string;
}
