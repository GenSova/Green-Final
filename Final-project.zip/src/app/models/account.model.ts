export class Account {
  id: number;
  email: string;
  password: string;
  password1: string;
  login: string;
}
