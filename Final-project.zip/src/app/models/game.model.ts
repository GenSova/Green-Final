export class Game {
  id: number;
  name: string;
  image: string;
}
